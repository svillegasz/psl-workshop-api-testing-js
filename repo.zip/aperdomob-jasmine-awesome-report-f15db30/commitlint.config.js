module.exports = {
  extends: ['@commitlint/config-angular']
};
